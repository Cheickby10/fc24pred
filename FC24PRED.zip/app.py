
import streamlit as st
import pandas as pd
import random
from teams import teams

st.set_page_config(page_title="FC24PRED", layout="centered")

st.title("⚽ FC24PRED – Bot de Prédiction FC24 4x4")
st.markdown("Prédictions de matchs Premier League (FIFA FC24 4x4) avec stats par mi-temps.")

# Charger ou créer l'historique
results_file = "results.csv"
try:
    history = pd.read_csv(results_file)
except FileNotFoundError:
    history = pd.DataFrame(columns=["Équipe 1", "Équipe 2", "Score", "Mi-temps 1", "Mi-temps 2", "Gagnant"])

# Sélection des équipes
col1, col2 = st.columns(2)
with col1:
    team1 = st.selectbox("Équipe 1", list(teams.keys()))
with col2:
    team2 = st.selectbox("Équipe 2", list(teams.keys()), index=1)

if team1 == team2:
    st.warning("Choisissez deux équipes différentes.")
    st.stop()

# Fonction de prédiction
def predict_match(t1, t2):
    r1, r2 = teams[t1]["rating"], teams[t2]["rating"]
    rating_diff = r1 - r2 + random.randint(-2, 2)
    
    def mi_temps_score(base, advantage):
        prob = min(90, max(50, 70 + advantage * 2))
        goals = max(0, min(3, base + random.choice([0, 1])))
        return goals, prob

    advantage = (r1 - r2) // 2
    ht1_goals, ht1_prob = mi_temps_score(random.randint(0, 1), advantage)
    ht2_goals, ht2_prob = mi_temps_score(random.randint(0, 1), -advantage)
    ft1, ft2 = ht1_goals + ht2_goals, random.randint(0, 3)

    if rating_diff > 2:
        ft2 = max(0, ft2 - 1)
    elif rating_diff < -2:
        ft1 = max(0, ft1 - 1)

    winner = t1 if ft1 > ft2 else (t2 if ft2 > ft1 else "Match nul")
    return ft1, ft2, ht1_goals, ht2_goals, ht1_prob, ht2_prob, winner

# Prédire
if st.button("🔮 Prédire le match"):
    ft1, ft2, ht1, ht2, p1, p2, winner = predict_match(team1, team2)
    st.subheader("Résultat Prévu :")
    st.markdown(f"**{team1} {ft1} - {ft2} {team2}**")
    st.markdown(f"**1ère mi-temps**: {team1} {ht1} (📊 {p1}%) | {team2} {ht2} (📊 {p2}%)")
    st.markdown(f"🏆 **Gagnant Probable** : {winner}")

    # Ajouter à l'historique
    new_result = {
        "Équipe 1": team1,
        "Équipe 2": team2,
        "Score": f"{ft1}-{ft2}",
        "Mi-temps 1": f"{ht1}-{ht2}",
        "Mi-temps 2": f"{ft1-ht1}-{ft2-ht2}",
        "Gagnant": winner
    }
    history = pd.concat([pd.DataFrame([new_result]), history], ignore_index=True)
    history.to_csv(results_file, index=False)

# Affichage de l'historique
st.subheader("📜 Historique des matchs")
st.dataframe(history.head(10))
