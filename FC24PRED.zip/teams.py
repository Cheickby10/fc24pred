
teams = {
    "Arsenal": {"players": ["Saka", "Rice", "Odegaard", "Saliba"], "rating": 84},
    "Man City": {"players": ["Haaland", "KDB", "Foden", "Walker"], "rating": 88},
    "Chelsea": {"players": ["Nkunku", "Sterling", "Enzo", "James"], "rating": 82},
    "Liverpool": {"players": ["Salah", "Jota", "Szoboszlai", "TAA"], "rating": 85},
    "Man Utd": {"players": ["Rashford", "Bruno", "Garnacho", "Dalot"], "rating": 83},
    "Tottenham": {"players": ["Son", "Maddison", "Kulusevski", "Romero"], "rating": 83},
    "Newcastle": {"players": ["Isak", "Gordon", "Guimaraes", "Trippier"], "rating": 82},
    "Aston Villa": {"players": ["Watkins", "Bailey", "McGinn", "Carlos"], "rating": 81},
    "Brighton": {"players": ["Ferguson", "Mitoma", "Gilmour", "Dunk"], "rating": 80},
    "West Ham": {"players": ["Paqueta", "Bowen", "Ward-Prowse", "Zouma"], "rating": 80},
    "Everton": {"players": ["Calvert-Lewin", "Doucoure", "Tarkowski", "Pickford"], "rating": 78},
    "Brentford": {"players": ["Toney", "Mbeumo", "Janelt", "Mee"], "rating": 78},
    "Crystal Palace": {"players": ["Eze", "Olise", "Lerma", "Andersen"], "rating": 78},
    "Wolves": {"players": ["Cunha", "Neto", "Lemina", "Kilman"], "rating": 77},
    "Fulham": {"players": ["Jimenez", "Willian", "Palhinha", "Ream"], "rating": 77},
    "Bournemouth": {"players": ["Solanke", "Tavernier", "Cook", "Kelly"], "rating": 77},
    "Nottingham Forest": {"players": ["Awoniyi", "Gibbs-White", "Yates", "Niakhaté"], "rating": 76},
    "Burnley": {"players": ["Rodriguez", "Brownhill", "Cullen", "Taylor"], "rating": 75},
    "Sheffield Utd": {"players": ["McBurnie", "Norwood", "Robinson", "Ahmedhodzic"], "rating": 74},
    "Luton Town": {"players": ["Adebayo", "Clark", "Nakamba", "Lockyer"], "rating": 74}
}
